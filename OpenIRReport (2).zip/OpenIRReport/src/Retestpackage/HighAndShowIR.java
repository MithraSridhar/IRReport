package Retestpackage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import jxl.*;
import jxl.read.biff.BiffException;
import jxl.write.*;
import jxl.write.Number;
import jxl.write.biff.RowsExceededException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONObject;


//import com.vdsi.batch3.dto.SearchResultIrDTO;

public class HighAndShowIR {	
	static WritableCellFormat cellFormat;	
	static HashSet<String> hs = new HashSet<String>();
	static HashMap<String,String> al=new HashMap<String,String>();
	
	//Un comment  while Running Jenkins Job
	
/*	static final String EXCEL_FILE_LOCATION = "D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\OpenIR.xls";  
	static final String HTML_FILE_LOCATION="D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\Test.html";
	static final String EXCEL_FILE_LOCATION_REPORT="D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\OpenIRMetrics.xls";*/
	
	//Local Files
	
	
	static final String EXCEL_FILE_LOCATION = "C:\\URLCheck\\AutoURL\\OpenIR.xls";  
    static final String EXCEL_FILE_LOCATION_REPORT = "C:\\URLCheck\\AutoURL\\OpenIRMetrics.xls";  
    static final String HTML_FILE_LOCATION="C:\\URLCheck\\AutoURL\\Test1.html";
    static final String HTML_FILE_LOCATION_RETEST="C:\\URLCheck\\AutoURL\\Test.html";
    static final String EXCEL_FILE_LOCATION_RETEST = "C:\\URLCheck\\AutoURL\\RetestIR.xls";  
    static final String EXCEL_FILE_LOCATION_REPORT_RETEST = "C:\\URLCheck\\AutoURL\\RetestIRMetrics.xls";  
	static final String REPORT_OPEN="C:\\URLCheck\\AutoURL\\Test1.html";
    static final String REPORT_RETEST="C:\\URLCheck\\AutoURL\\Test.html";
    static final String HTML_TOP="C:\\URLCheck\\AutoURL\\TestHigh.html";
    static final String QUERY_GENERATOR="C:\\URLCheck\\AutoURL\\QueryGenerator.xlsx";
    static final String HTML_FILE_LOCATION_REG="C:\\URLCheck\\AutoURL\\TestReg.html";
	static final String HTML_TOP_REG="C:\\URLCheck\\AutoURL\\TestReghigh.html";
	static final String HTML_TOP_CONS_REG="C:\\URLCheck\\AutoURL\\TestCons.html";

	//Un comment  while Running Jenkins Job
	
/*  static final String HTML_FILE_LOCATION_RETEST="D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\Test1.html";
   static final String EXCEL_FILE_LOCATION_RETEST = "D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\RetestIR.xls";  
    static final String EXCEL_FILE_LOCATION_REPORT_RETEST ="D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\RetestIRMetrics.xls";  
	static final String REPORT_OPEN="D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\Test.html";
   static final String REPORT_RETEST="D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\Test1.html";
    static final String QUERY_GENERATOR="D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\QueryGenerator.xlsx";
	static final String HTML_TOP="D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\TestHigh.html";
	 static final String HTML_FILE_LOCATION_REG="D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\TestReg.html";
	   static final String HTML_TOP_REG="D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\TestReghigh.html";
	   static final String HTML_TOP_CONS_REG="D:\\jenkins\\workspace\\CMB.EIQV.OVERALLOPENIR.TEST\\ReTest\\TestCons.html";*/
   
	   static FileOutputStream fo;
	static String QueryCreation="";
	static OutputStreamWriter objResFile;
	static Map<String, Integer> TotalCount=new HashMap<String,Integer>();	
	static int GHL=0;static int GSL=0;static int GTI=0;
	static int ZeroToOneHL=0,OneToTwoHL=0,TwoToThreeHL=0,ThreeToFiveHL=0,FiveToTenHL=0,TendaysplusHL=0,TotaldaysAgedHL=0;
	static int ZeroToOne=0,OneToTwo=0,TwoToThree=0,ThreeToFive=0,FiveToTen=0,Tendaysplus=0,TotaldaysAged=0;
			
	@SuppressWarnings("unused")
	public static void main(String[] args) throws ParseException, IOException, BiffException {	
		CreateheaderResultFile(HTML_FILE_LOCATION,0);
		HttpGet request = null; 
		
		 String filePath = QUERY_GENERATOR;	
	
		 al=new ValidateExcel().ReadExcel(filePath);
		 System.out.println(al);
		 for (Map.Entry<String, String> entry : al.entrySet()) {
		 	    String key = entry.getKey().trim();				 	    
		 	    if(key.contains(" ")||key.contains("(")){
		 	       QueryCreation=QueryCreation+"+cf[10823]~'"+key.replace(" ", "+")+"'+OR";
		 	    }
		 	    else
		 	    {	
		 	    	QueryCreation=QueryCreation+"+cf[10823]~"+key+"+OR";
		 	    }
		}   
			 	
	 	int Lastin=QueryCreation.lastIndexOf("+OR");
	 	int lenn=QueryCreation.length();
	 	QueryCreation=QueryCreation.substring(1, Lastin);
		System.out.println(QueryCreation);
	
	 	request = new HttpGet("https://onejira.verizon.com/rest/api/2/search?jql=project=ITT+AND+issuetype=Bug+AND+Priority_3+in+('High(Critical)','Urgent(Show+Stopper)')+AND+status!=Close+AND+status!=Blocked+AND+status!=Retest+AND+("+QueryCreation+")+ORDER+BY+updated+ASC&startAt=0&maxResults=1000&fields=customfield_48700,customfield_10823,customfield_11847,customfield_10677,customfield_10683,customfield_11855,created,updated,summary,status,reporter");
	    String encoding = new String(Base64.encodeBase64(("gopami4"+":"+"mithusRI1307*").getBytes()));
	    request.setHeader("Authorization", "Basic " + encoding);
	    String apiOutput = null;  
	   
	     try{ 
	    	  DefaultHttpClient httpClient = new DefaultHttpClient(); 
	    	  HttpResponse response = httpClient.execute(request);
	 	      //SearchResultIrDTO searchResultIrDTO = null; 
	          HttpEntity httpEntity = response.getEntity();
	          apiOutput = EntityUtils.toString(httpEntity);
	          System.out.println(apiOutput);
	          JSONObject jsonObj = new JSONObject(apiOutput);
	          JSONArray projectArray = jsonObj.getJSONArray("issues");
	          int IRCount=projectArray.length();
	          System.out.println("Total IR Count:::"+IRCount);
	          for (int i = 0; i <= projectArray.length()-1; i++) {
	               JSONObject proj=projectArray.getJSONObject(i);
	               int RowNumber=i+1;
	               String SubProject=proj.getJSONObject("fields").get("customfield_10823").toString().replaceAll("\\s", "");
	               String Priority=proj.getJSONObject("fields").getJSONObject("customfield_10683").get("value").toString().trim();
	               String ApplicationName=proj.getJSONObject("fields").getJSONObject("customfield_11847").get("value").toString().trim();
	               
	               String  ClarityProjectname =al.get(SubProject);
	               //String  ClarityProjectname =proj.getJSONObject("fields").getJSONObject("customfield_48700").toString();
	               System.out.println("****"+ClarityProjectname+"*******");
	               String KeyName=proj.getString("key");
	               String ReleaseValue=proj.getJSONObject("fields").getJSONObject("customfield_11855").get("value").toString().trim();
	               Thread.sleep(10000);
	               String ReporterName=proj.getJSONObject("fields").getJSONObject("reporter").getString("emailAddress");
	               String SUmmaryName=proj.getJSONObject("fields").getString("summary");
	               Thread.sleep(10000);
	               String ReporterVal=proj.getJSONObject("fields").getJSONObject("reporter").get("displayName").toString().trim();
	               //String LoggedValuu=proj.getJSONObject("fields").getJSONObject("customfield_10677").get("value").toString().trim();
	               String StatusName=proj.getJSONObject("fields").getJSONObject("status").get("name").toString().trim();	  
	               String []  CreatedDate=proj.getJSONObject("fields").getString("created").split("-");
	               String[]  UpdatedDate=proj.getJSONObject("fields").getString("updated").split("-");
	               DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	               Date date = new Date();
	               String TodayDate=dateFormat.format(date);
	               Date createddatedd = dateFormat.parse(CreatedDate[0]+"-"+CreatedDate[1]+"-"+CreatedDate[2].substring(0,2));	               
	    		   Date todayyy = dateFormat.parse(TodayDate);	    		
	    		   long diff = todayyy.getTime() - createddatedd.getTime();
	    		   long dd=TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	    		   if(dd<0){
	    			   dd=0;
	    		   }
	    		   
	    		   if(SubProject!=null){
	    			   hs.add(ClarityProjectname);
	    		   }else{
	    			   hs.add(ClarityProjectname);
	    		   }
	               
	               writeExcel(RowNumber,ClarityProjectname,ApplicationName,Priority,dd,KeyName,SUmmaryName,StatusName,EXCEL_FILE_LOCATION);
	               writeExcelReport(RowNumber,KeyName,SUmmaryName,StatusName,CreatedDate[0]+"-"+CreatedDate[1]+"-"+CreatedDate[2],UpdatedDate[0]+"-"+UpdatedDate[1]+"-"+UpdatedDate[2],dd,ApplicationName,ReleaseValue,Priority,ReporterVal,SubProject,ClarityProjectname,EXCEL_FILE_LOCATION_REPORT);
	          }
      System.out.println(hs);
	          for (String temp : hs) {
	             	String ProjectNameList=temp;
	             	ReadExcel(ProjectNameList,EXCEL_FILE_LOCATION,HTML_FILE_LOCATION);
	          }
	      }
	      catch(Exception e){
	    		System.out.println(e.getMessage());
	      }
	     
	    
	     ReadExcelForGenerateReport(EXCEL_FILE_LOCATION,HTML_FILE_LOCATION,0);
	     TotalCount.clear();
	     //CallReTestIR();
	     
	    // new SQEFALLOUT();
		 //SQEFALLOUT.RegressionIR();
	     Consolidated();
	   
	     String tex=ReadTextFile();
	     //String tex1=ReadTextFile1();

	     //String Reggg=ReadTextFileReg();
	     
	     //String RegggCon=ReadTextFileRegCon();
	    
	     FileWriter fw = new FileWriter(HTML_TOP,true); //the true will append the new data
	    // fw.write(Reggg);//appends the string to the file
	     fw.write(tex);//appends the string to the file
	     //fw.write(tex1);//appends the string to the file
	    // fw.write(RegggCon);//appends the string to the file
	     fw.close();
	    
     }
	public static String   ReadTextFile() throws IOException
    {   
    	File file = new File(REPORT_OPEN);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		StringBuffer stringBuffer = new StringBuffer();
		String line=bufferedReader.readLine();
		return line;

    
    }
	
	public static String   ReadTextFileReg() throws IOException
    {   
    	File file = new File(HTML_TOP_CONS_REG);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		StringBuffer stringBuffer = new StringBuffer();
		String line=bufferedReader.readLine();
		return line;

    
    }
	
	public static String   ReadTextFileRegCon() throws IOException
    {   
    	File file = new File(HTML_TOP_REG);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		StringBuffer stringBuffer = new StringBuffer();
		String line=bufferedReader.readLine();
		return line;

    
    }
	
	/*public static String   ReadTextFile1() throws IOException
    {   
    	File file = new File(REPORT_RETEST);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		StringBuffer stringBuffer = new StringBuffer();
		String line=bufferedReader.readLine();
		return line;

    
    }*/
	@SuppressWarnings("deprecation")
	public static void writeExcel(int num,String RowLabels,String ApplicationList, String PriorityName, long days,String KeyH,String SUN,String StN,String FileName) throws RowsExceededException, WriteException, IOException, BiffException  {
        
    	Workbook  OResults=Workbook.getWorkbook(new File(FileName));
    	WritableWorkbook OVResult=Workbook.createWorkbook(new File(FileName),OResults);
    	WritableSheet sheet2=OVResult.getSheet(0); 
    	WritableFont cellFont = new WritableFont(WritableFont.TIMES, 12);
   	    cellFont.setColour(Colour.BLACK);
   	    cellFormat = new WritableCellFormat(cellFont);
 	    cellFormat.setBackground(Colour.WHITE);
 	    cellFormat.setBorder(Border.ALL, BorderLineStyle.THIN); 
    	 
        Label IssVa = new Label(0, num,RowLabels,cellFormat);
        sheet2.addCell(IssVa);
        
        Label KeyVa = new Label(1, num, ApplicationList,cellFormat);
   		sheet2.addCell(KeyVa);
   		
   		if(PriorityName.contains("High")){
   	       Label SummVa = new Label(2,num,"High(Critical)",cellFormat);
		   sheet2.addCell(SummVa); 
		   Number numER = new Number(4,num,(int)days);
		   sheet2.addCell(numER); 
		   
   		}
   		else{
		   Label RepVa = new Label(3,num,"Urgent(Show Stopper)",cellFormat);
   		   sheet2.addCell(RepVa); 	
   		 Number numtr = new Number(5,num,(int)days);
		   sheet2.addCell(numtr); 
   		}   	
   		
   	    Label KeyVal = new Label(6, num, KeyH,cellFormat);
		sheet2.addCell(KeyVal);
		
		Label SummaryNa = new Label(7, num, SUN,cellFormat);
		sheet2.addCell(SummaryNa);
		
		Label Statuu = new Label(8, num, StN,cellFormat);
		sheet2.addCell(Statuu);
		
		/*Label PriorityNaa = new Label(9, num, PriorityN,cellFormat);
		sheet2.addCell(PriorityNaa);*/
   		   		
   		OVResult.write();
   		OVResult.close();
   		OResults.close();

    
    }
	
	public static void ReadExcelForGenerateReport(String FileLocation,String FileName, int num) throws IOException{
		ZeroToOneHL=0;
		OneToTwoHL=0;
		TwoToThreeHL=0;
		ThreeToFiveHL=0;
		FiveToTenHL=0;
		TendaysplusHL=0;
		ZeroToOne=0;
		OneToTwo=0;
		TwoToThree=0;
		ThreeToFive=0;
		FiveToTen=0;
		Tendaysplus=0;
		
		 
		 Workbook workbookAged = null;
	     try {
	    	    int AgedNum=0;int AgedNumFa=0;
	    	    workbookAged = Workbook.getWorkbook(new File(FileLocation));
	            Sheet sheet = workbookAged.getSheet(0);
	            int Rwcount=sheet.getRows();
	            for(int Rr=1;Rr<Rwcount;Rr++){
	                Cell cell1 = sheet.getCell(4, Rr);
	                String PC=cell1.getContents().trim();
	               
	                Cell cell33 = sheet.getCell(5, Rr);
	                String NC=cell33.getContents().trim();
	               
	              if(!PC.equals(""))  {
	            	   AgedNum=Integer.parseInt(PC);
	                if(AgedNum<=1){
	                	ZeroToOneHL=ZeroToOneHL+1;
	                }
	                else if(AgedNum<=2){
	                	OneToTwoHL=OneToTwoHL+1;
	                }
	                else if(AgedNum<=3){
	                	TwoToThreeHL=TwoToThreeHL+1;
	                }
	                else if(AgedNum<=5){
	                	ThreeToFiveHL=ThreeToFiveHL+1;
	                }
	                else if(AgedNum<=10){
	                	FiveToTenHL=FiveToTenHL+1;
	                }
	                else if(AgedNum>10){
	                	TendaysplusHL=TendaysplusHL+1;
	                }
	              }  
	                if(!NC.equals("")){
		                 AgedNumFa=Integer.parseInt(NC);
	                if(AgedNumFa<=1){
	                	ZeroToOne=ZeroToOne+1;
	                }
	                else if(AgedNumFa<=2){
	                	OneToTwo=OneToTwo+1;
	                }
	                else if(AgedNumFa<=3){
	                	TwoToThree=TwoToThree+1;
	                }
	                else if(AgedNumFa<=5){
	                	ThreeToFive=ThreeToFive+1;
	                }
	                else if(AgedNumFa<=10){
	                	FiveToTen=FiveToTen+1;
	                }
	                else if(AgedNumFa>10){
	                	Tendaysplus=Tendaysplus+1;
	                }
	              }   
	            }
	            
	     }
	     catch(Exception e){
	    	 
	     }
	     
	     CloseResultFile(ZeroToOne,OneToTwo,TwoToThree,ThreeToFive,FiveToTen,Tendaysplus,ZeroToOneHL,OneToTwoHL,TwoToThreeHL,ThreeToFiveHL,FiveToTenHL,TendaysplusHL,FileName,num);
	}
	
	@SuppressWarnings("deprecation")
	public static void writeExcelReport(int num,String KeyValue,String SummaryValue, String StatusValue, String CreatedValue,String UpdatedValue,long days,String ApplicationValue,String ReleaseValue,String PriorityValue,String ReporterValue,String SubProjectValue,String ClarityprojectNameValue,String FileLocation) throws RowsExceededException, WriteException, IOException, BiffException  {
        
    	Workbook  OResults=Workbook.getWorkbook(new File(FileLocation));
    	WritableWorkbook OVResult=Workbook.createWorkbook(new File(FileLocation),OResults);
    	WritableSheet sheet2=OVResult.getSheet(0); 
    	WritableFont cellFont = new WritableFont(WritableFont.ARIAL, 9);
   	    cellFont.setColour(Colour.BLACK);
   	    cellFormat = new WritableCellFormat(cellFont);
 	    cellFormat.setBackground(Colour.WHITE);
 	    cellFormat.setBorder(Border.ALL, BorderLineStyle.THIN); 
    	 
        Label K1 = new Label(0, num,KeyValue,cellFormat);
        sheet2.addCell(K1);
        
        Label K2 = new Label(1, num, SummaryValue,cellFormat);
   		sheet2.addCell(K2);
   		
   	    Label K3 = new Label(2, num, StatusValue,cellFormat);
		sheet2.addCell(K3);
   		
   	    Label K4 = new Label(3, num, CreatedValue,cellFormat);
		sheet2.addCell(K4);
		
		Label K5 = new Label(4, num, UpdatedValue,cellFormat);
		sheet2.addCell(K5);
		
		 Number numtr = new Number(5,num,(int)days,cellFormat);
		 sheet2.addCell(numtr);
		
		
		Label K8 = new Label(7, num, ApplicationValue,cellFormat);
		sheet2.addCell(K8);
		
		Label K9 = new Label(8, num, ReleaseValue,cellFormat);
		sheet2.addCell(K9);	
	
		
		Label K11 = new Label(9, num, PriorityValue,cellFormat);
		sheet2.addCell(K11);
		
		Label K12 = new Label(10, num, ReporterValue,cellFormat);
		sheet2.addCell(K12);
		
		
		Label K13 = new Label(11, num, SubProjectValue,cellFormat);
		sheet2.addCell(K13);
		
		
		Label K14 = new Label(12, num, ClarityprojectNameValue,cellFormat);
		sheet2.addCell(K14);
		
		
		
		
   		   		
   		OVResult.write();
   		OVResult.close();
   		OResults.close();

    
    }
	
	public static void ReadExcel(String Projt,String FileLocation,String HTMLFileLocation) throws IOException {  
		   Map<String,String> Calculation=new HashMap<String,String>();
		   Map<String,Integer> HighLevelIR=new HashMap<String,Integer>();
		   Map<String,Integer> ShowStopperIR=new HashMap<String,Integer>();
	        Workbook workbook = null;
	        try {
	            workbook = Workbook.getWorkbook(new File(FileLocation));
	            Sheet sheet = workbook.getSheet(0);
	            int Rwcount=sheet.getRows();
	            for(int Rr=1;Rr<Rwcount;Rr++){
	                Cell cell1 = sheet.getCell(0, Rr);
	                String PC=cell1.getContents().trim();
	                if(PC.equals(Projt)){
	                	
	                	Cell cell2 = sheet.getCell(1, Rr);String AL=cell2.getContents().trim();
	  	                Cell cell3 = sheet.getCell(2, Rr);String HI=cell3.getContents().trim();
	  	                Cell cell4 = sheet.getCell(3, Rr);String SI=cell4.getContents().trim();
	  	                Calculation.put(AL, Projt);
	  	                if(!HI.equals("")){
	  	                	try{
	  	                		int valtr=HighLevelIR.get(AL);
	  	                		HighLevelIR.put(AL, valtr+1);
	  	                	}catch(Exception e){
	  	                		HighLevelIR.put(AL, 1);
	  	                	}
	  	                }
	  	                
	  	                if(!SI.equals("")){
	  	                	try{
	  	                		int valule=ShowStopperIR.get(AL);
	  	                		ShowStopperIR.put(AL, valule+1);
	  	                	}catch(Exception e){
	  	                		ShowStopperIR.put(AL, 1);
	  	                	}
	  	                }
	  	                 
	                }
	              
	               
	            }    
	            
	            UpdateFile(Projt,Calculation,HighLevelIR,ShowStopperIR,HTMLFileLocation);
	            Calculation=null;
	            HighLevelIR=null;
	            ShowStopperIR=null;

	        } catch (IOException e) {
	            e.printStackTrace();
	        } catch (BiffException e) {
	            e.printStackTrace();
	        } finally {

	            if (workbook != null) {
	                workbook.close();
	            }

	        }
	        
	       

	    }
	
	 public static void CreateheaderResultFile(String FileLocation ,int num) throws IOException{
	            
		     fo = new FileOutputStream(FileLocation);	                    
	         //objResFile = new OutputStreamWriter(new FileOutputStream("D:\\jenkins_jnlp\\workspace\\CMB.EIQV.DailyCurrentReleaseRETESTIR.TEST\\ReTest\\Test1.html"));
	         objResFile = new OutputStreamWriter(new FileOutputStream(FileLocation));
	         objResFile.write("<!DOCTYPE html>");
	         objResFile.write("<html>");
	         objResFile.write("<head>");                                 
	         objResFile.write("</head>");
	         objResFile.write("<body>");
	         if(num==0){        	 
		     	  objResFile.write("<p><font face= Arial size=4>Please find below the Open IR's Summary</font></p>");}
	         else{
	        	 objResFile.write("<p><font face= Arial size=4>Please find below the Retest IR's Summary</font></p>");
	         }
	         objResFile.write("<table border=1 cellpadding=0 cellspacing=0 background-color: #FF7F50>");
	         objResFile.write("<tr bgcolor="+"#00BFFF>");
	         objResFile.write("<th><font face= Arial size=2>Project</font></th>");
	         objResFile.write("<th><font face= Arial size=2>Application List</font></th>");
	         objResFile.write("<th><font face= Arial size=2>L2-High(Critical)</font></th>");
	         objResFile.write("<th><font face= Arial size=2>L1-Urgent(Show Stopper)</font></th>");
	         objResFile.write("<th><font face= Arial size=2>Grand Total</font></th>");	                  
	         objResFile.write("</tr>");	       
	         objResFile.close();
	 }
	 
	 public static void UpdateFile(String ProjectNameId,Map<String, String> RLL, Map<String, Integer> HLL, Map<String, Integer> SLL,String FileLocation) throws IOException{
		 
		 
		 String GettingPN="";int counter=0;
		     int HLVal=0;int SSVal=0;
		     OutputStreamWriter objResFile = new OutputStreamWriter(new FileOutputStream(FileLocation,true));
		    //OutputStreamWriter objResFile = new OutputStreamWriter(new FileOutputStream("D:\\jenkins_jnlp\\workspace\\CMB.EIQV.DailyCurrentReleaseRETESTIR.TEST\\ReTest\\Test1.html",true));             
           
            for (Map.Entry<String, String> entry : RLL.entrySet()) {
    			 GettingPN=entry.getKey();
    			 try{
    			 HLVal=HLL.get(GettingPN);    			 
    			 }
    			 catch(Exception e){    				
    			 }
    			 
    			 try{
    				 SSVal=SLL.get(GettingPN);
    			 }catch(Exception e){    				
    			 }
    		
               objResFile.write("<tr>");
               if(counter==0){
               objResFile.write("<td><font face= Arial size=2>"+ProjectNameId+"</font></td>");}
               else{
            	   objResFile.write("<td><font face= Arial size=2></font></td>");   
               }
               objResFile.write("<td><font face= Arial size=2>"+GettingPN+"</font></td>");
               objResFile.write("<th><font face= Arial size=2>"+HLVal+"</font></th>");
               objResFile.write("<th><font face= Arial size=2>"+SSVal+"</font></th>");
               objResFile.write("<th><font face= Arial size=2>"+(HLVal+SSVal)+"</font></th>");       
               objResFile.write("</tr>");              
               counter=counter+1;
          
               try{
            	   GHL=TotalCount.get("HLIR");
            	   TotalCount.put("HLIR", GHL+HLVal);
               }
               catch(Exception e){
            	   TotalCount.put("HLIR",HLVal);
               }
               
               try{
            	   GSL=TotalCount.get("SLIR");
            	   TotalCount.put("SLIR", GSL+SSVal);
               }
               catch(Exception e){
            	   TotalCount.put("SLIR",SSVal);
               }
               
               try{
            	   GTI=TotalCount.get("TLR");
            	   TotalCount.put("TLR", GTI+HLVal+SSVal);
               }
               catch(Exception e){
            	   TotalCount.put("TLR",(HLVal+SSVal));
               }
               HLVal=0;
               SSVal=0;
          }
            objResFile.close();
     }
	 
	 
	 public static void CloseResultFile(int Fir,int Sec, int Thi, int Fou, int Fiv, int Six, int Sev, int Eig,int Nin,int Ten, int Ele, int Twe,String FileLocation, int Num) throws IOException{
	        OutputStreamWriter objResFile = new OutputStreamWriter(new FileOutputStream(FileLocation,true));
	        //OutputStreamWriter objResFile = new OutputStreamWriter(new FileOutputStream("D:\\jenkins_jnlp\\workspace\\CMB.EIQV.DailyCurrentReleaseRETESTIR.TEST\\ReTest\\Test1.html",true));                
	        objResFile.write("<tr bgcolor="+"#00BFFF>");
	        objResFile.write("<td><font face= Arial size=2>Total</font></td>");
	        objResFile.write("<td><font face= Arial size=2>  </font></td>");
	        objResFile.write("<th><font face= Arial size=2>"+TotalCount.get("HLIR")+"</font></th>");
            objResFile.write("<th><font face= Arial size=2>"+TotalCount.get("SLIR")+"</font></th>");
            objResFile.write("<th><font face= Arial size=2>"+TotalCount.get("TLR")+"</font></th>");
            objResFile.write("</tr>");       
	        objResFile.write("</table>"); 
	        if(Num==0){
	           objResFile.write("<p><font face= Arial size=4>Please find below the Open Aged IR's Summary(in Days)</font></p>");
	        }
	        else{
	        objResFile.write("<p><font face= Arial size=4>Please find below the ReTest Aged IR's Summary(in Days)</font></p>");
	        }
	        objResFile.write("<table width=50% border=1 cellpadding=0 cellspacing=0 background-color: #FF7F50>");
	        objResFile.write("<tr bgcolor="+"#00CED1>"); 
	        objResFile.write("<th><font face= Arial size=2>Priority</font></th>");
	        objResFile.write("<th><font face= Arial size=2>0-1</font></th>");
	        objResFile.write("<th><font face= Arial size=2>1-2</font></th>");
	        objResFile.write("<th><font face= Arial size=2>2-3</font></th>");
	        objResFile.write("<th><font face= Arial size=2>3-5</font></th>");
	        objResFile.write("<th><font face= Arial size=2>5-10</font></th>");
	        objResFile.write("<th><font face= Arial size=2>>10</font></th>");   
	        objResFile.write("<th><font face= Arial size=2>Total</font></th>"); 
	        objResFile.write("</tr>"); 
	        objResFile.write("<tr bgcolor="+"#e1f9e3>");	        
	        objResFile.write("<th><font face= Arial size=2>L1</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+Fir+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+Sec+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+Thi+"</font></th>");	
	        objResFile.write("<th><font face= Arial size=2>"+Fou+"</font></th>");	  
	        objResFile.write("<th><font face= Arial size=2>"+Fiv+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+Six+"</font></th>");	  
	        objResFile.write("<th><font face= Arial size=2>"+(Fir+Sec+Thi+Fou+Fiv+Six)+"</font></th>");	        
	        objResFile.write("</tr>");
	        objResFile.write("<tr bgcolor="+"#e1f9e3>");	        
	        objResFile.write("<th><font face= Arial size=2>L2</font></td>");      	  
	     	objResFile.write("<th><font face= Arial size=2>"+Sev+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+Eig+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+Nin+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+Ten+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+Ele+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+Twe+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+(Sev+Eig+Nin+Ten+Ele+Twe)+"</font></th>");	
	        objResFile.write("</tr>"); 
	        objResFile.write("<tr bgcolor="+"#00CED1>");  
	        objResFile.write("<th><font face= Arial size=2>Total</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+(Fir+Sev)+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+(Sec+Eig)+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+(Thi+Nin)+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+(Fou+Ten)+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+(Fiv+Ele)+"</font></th>");  
	        objResFile.write("<th><font face= Arial size=2>"+(Six+Twe)+"</font></th>");
	        objResFile.write("<th><font face= Arial size=2>"+(Fir+Sec+Thi+Fou+Fiv+Six+Sev+Eig+Nin+Ten+Ele+Twe)+"</font></th>");
	        objResFile.write("</tr>"); 
	        objResFile.write("</table>");     
	        objResFile.write("</body>");     
	        objResFile.write("</html>");	             
	        objResFile.close();
	    
	  }
	 
	 public static void CallReTestIR() throws IOException{
		 
		 
		 CreateheaderResultFile(HTML_FILE_LOCATION_RETEST,1);
		 HttpGet request = null; 

			request = new HttpGet("https://onejira.verizon.com/rest/api/2/search?jql=project=ITT+AND+issuetype=Bug+AND+Priority_3+in+('High(Critical)','Urgent(Show+Stopper)')+AND+status=Retest+AND+("+QueryCreation+")+ORDER+BY+updated+ASC&startAt=0&maxResults=1000&fields=customfield_48700,customfield_10823,customfield_11847,customfield_10677,customfield_10683,customfield_11855,created,updated,summary,status,reporter");
		    String encoding = new String(Base64.encodeBase64(("gopami4"+":"+"mithusRI1307*").getBytes()));
		    request.setHeader("Authorization", "Basic " + encoding);
		    String apiOutput = null;  
		     try{ 
		    	  DefaultHttpClient httpClient = new DefaultHttpClient(); 
		    	  HttpResponse response = httpClient.execute(request);
		 	     // SearchResultIrDTO searchResultIrDTO = null; 
		          HttpEntity httpEntity = response.getEntity();
		          apiOutput = EntityUtils.toString(httpEntity);
		          System.out.println(apiOutput);
		          JSONObject jsonObj = new JSONObject(apiOutput);
		          JSONArray projectArray = jsonObj.getJSONArray("issues");
		          int IRCount=projectArray.length();
		          System.out.println("Total IR Count:::"+IRCount);
		          for (int i = 0; i <= projectArray.length()-1; i++) {
		               JSONObject proj=projectArray.getJSONObject(i);
		               int RowNumber=i+1;
		               String SubProject=proj.getJSONObject("fields").get("customfield_10823").toString().trim().replace(" ", "");
		               String Priority=proj.getJSONObject("fields").getJSONObject("customfield_10683").get("value").toString().trim();
		               String ApplicationName=proj.getJSONObject("fields").getJSONObject("customfield_11847").get("value").toString().trim();	             
		              // String  ClarityProjectname =proj.getJSONObject("fields").get("customfield_48700").toString();
		               String  ClarityProjectname =al.get(SubProject);
		               String KeyName=proj.getString("key");
		               String ReleaseValue=proj.getJSONObject("fields").getJSONObject("customfield_11855").get("value").toString().trim();
		               String SUmmaryName=proj.getJSONObject("fields").getString("summary");
		               Thread.sleep(10000);
		               String ReporterVal=proj.getJSONObject("fields").getJSONObject("reporter").get("displayName").toString().trim();
		               String LoggedValuu=proj.getJSONObject("fields").getJSONObject("customfield_10677").get("value").toString().trim();
		               String StatusName=proj.getJSONObject("fields").getJSONObject("status").get("name").toString().trim();	  
		               String []  CreatedDate=proj.getJSONObject("fields").getString("created").split("-");
		               String[]  UpdatedDate=proj.getJSONObject("fields").getString("updated").split("-");
		               DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		               Date date = new Date();
		               String TodayDate=dateFormat.format(date);
		               Date createddatedd = dateFormat.parse(CreatedDate[0]+"-"+CreatedDate[1]+"-"+CreatedDate[2].substring(0,2));	               
		    		   Date todayyy = dateFormat.parse(TodayDate);	    		
		    		   long diff = todayyy.getTime() - createddatedd.getTime();
		    		   long dd=TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		    		   if(dd<0){
		    			   dd=0;
		    		   }
		               hs.add(ClarityProjectname);
		               writeExcel(RowNumber,ClarityProjectname,ApplicationName,Priority,dd,KeyName,SUmmaryName,StatusName,EXCEL_FILE_LOCATION_RETEST);
		               writeExcelReport(RowNumber,KeyName,SUmmaryName,StatusName,CreatedDate[0]+"-"+CreatedDate[1]+"-"+CreatedDate[2],UpdatedDate[0]+"-"+UpdatedDate[1]+"-"+UpdatedDate[2],dd,ApplicationName,ReleaseValue,Priority,ReporterVal,SubProject,ClarityProjectname,EXCEL_FILE_LOCATION_REPORT_RETEST);
		          }
	      
		          for (String temp : hs) {
		             	String ProjectNameList=temp;
		             	ReadExcel(ProjectNameList,EXCEL_FILE_LOCATION_RETEST,HTML_FILE_LOCATION_RETEST);
		          }
		      }
		      catch(Exception e){
		    		System.out.println(e.getMessage());
		      }
		     
		     ReadExcelForGenerateReport(EXCEL_FILE_LOCATION_RETEST,HTML_FILE_LOCATION_RETEST,1);
	 }
	 
	 
	
    public static void Consolidated() throws IOException, BiffException{
    	 Workbook workbook = null;
		 int HighOpen=0;
		 int ShowOpen=0;
		 int HighCritical=0;
		 int ShowCritical=0;
		 workbook = Workbook.getWorkbook(new File(EXCEL_FILE_LOCATION_REPORT));
         Sheet sheet = workbook.getSheet(0);
         int Rwcount=sheet.getRows();
         for(int Rr=1;Rr<Rwcount;Rr++){
             Cell cell1 = sheet.getCell(9, Rr);
             String PC=cell1.getContents().trim();
           
             if(PC.contains("High")){
            	 HighOpen=HighOpen+1;
             }
             else{
            	 ShowOpen=ShowOpen+1; 
             }
             	
         }   	
         if (workbook != null) {
             workbook.close();
         }      
         
         workbook = Workbook.getWorkbook(new File(EXCEL_FILE_LOCATION_RETEST));
          sheet = workbook.getSheet(0);
          Rwcount=sheet.getRows();
         for(int Rr=1;Rr<Rwcount;Rr++){
             Cell cell1 = sheet.getCell(9, Rr);
             String PC=cell1.getContents().trim();
           
             if(PC.contains("High")){
            	 HighCritical=HighCritical+1;
             }
             else{
            	 ShowCritical=ShowCritical+1; 
             }
             	
         }   	
         if (workbook != null) {
             workbook.close();
         }         
	              
		 fo = new FileOutputStream(HTML_TOP);	
		objResFile = new OutputStreamWriter(new FileOutputStream(HTML_TOP));
        objResFile.write("<!DOCTYPE html>");
        objResFile.write("<html>");
        objResFile.write("<head>");                                 
        objResFile.write("</head>");
        objResFile.write("<body>");       
        objResFile.write("<p><font face= Arial size=4>Please find the consolidated list of Critical and Showstopper Open IRs.</font></p>");
        objResFile.write("<table border=1 cellpadding=0 cellspacing=0 background-color: #FF7F50>");
        objResFile.write("<tr bgcolor="+"#FF0000>");
        objResFile.write("<th colspan=5><font face= Arial size=3>Progression</font></th>");
        objResFile.write("</tr>");
        objResFile.write("<tr bgcolor="+"#00BFFF>");
        objResFile.write("<th><font face= Arial size=2>IR Type</font></th>");
        objResFile.write("<th><font face= Arial size=2>ShowStopper</font></th>");
        objResFile.write("<th><font face= Arial size=2>Critical</font></th>");
        objResFile.write("<th><font face= Arial size=2>Total</font></th>");                         
        objResFile.write("</tr>");	 
        objResFile.write("<tr bgcolor="+"#FFBF00>");
        objResFile.write("<th><font face= Arial size=2>Open IR</font></th>");
        objResFile.write("<th><font face= Arial size=2>"+ShowOpen+"</font></th>");
        objResFile.write("<th><font face= Arial size=2>"+HighOpen+"</font></th>");
        objResFile.write("<th><font face= Arial size=2>"+(HighOpen+ShowOpen)+"</font></th>");                         
        objResFile.write("</tr>");
        objResFile.write("<tr bgcolor="+"#FFBF00>");
        /*objResFile.write("<th><font face= Arial size=2>Retest IR</font></th>");;  
        objResFile.write("<th><font face= Arial size=2>"+ShowCritical+"</font></th>");
        objResFile.write("<th><font face= Arial size=2>"+HighCritical+"</font></th>");
        objResFile.write("<th><font face= Arial size=2>"+(ShowCritical+HighCritical)+"</font></th>");   */                    
        objResFile.write("</tr>");
        objResFile.write("</table>");
        objResFile.write("</body>");
        objResFile.write("</html>");
        objResFile.close();   	 
	     
	}
    
 }