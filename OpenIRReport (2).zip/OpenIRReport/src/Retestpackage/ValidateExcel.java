package Retestpackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.HashMap;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import jxl.Sheet;
import jxl.Workbook;

public class ValidateExcel {
	
	public HashMap<String,String> ReadExcel(String filePath) throws IOException{
		
		File file =    new File(filePath);
		HashMap<String,String> al=new HashMap<String,String>();
		
	    //Create an object of FileInputStream class to read excel file
		
	    FileInputStream inputStream = new FileInputStream(file);

	    XSSFWorkbook guru99Workbook = null;

	    //Find the file extension by splitting file name in substring  and getting only extension name

	 
	    guru99Workbook = new XSSFWorkbook(inputStream);

	   

	    //Read sheet inside the workbook by its name

	    XSSFSheet guru99Sheet = guru99Workbook.getSheet("Query");

	    //Find number of rows in excel file

	    int rowCount = guru99Sheet.getLastRowNum()-guru99Sheet.getFirstRowNum();

	    //Create a loop over all the rows of excel file to read it

	    for (int i = 1; i < rowCount+1; i++) {

	        Row row = guru99Sheet.getRow(i);

	        //Create a loop to print cell values in a row

	       

	        	String project=row.getCell(0).getStringCellValue().trim();
	        	String projectDesc=row.getCell(1).getStringCellValue().trim();

	        	al.put(project, projectDesc);

	       

	    }
	    
	    return al;
		
	}

}
