package Retestpackage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;

public class IRRetest {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("madhu");
		System.out.println(System.getProperty("user.dir"));
		File file =    new File("C:\\IRReteststatus\\Files\\RetestIRMetrics.xlsx");
        System.out.println(file);
        FileInputStream inputStream = new FileInputStream(file);
        Workbook RunManger = null;
        RunManger = new XSSFWorkbook(inputStream);
        Sheet sheet = RunManger.getSheet("Sheet1");
        int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
        Row row1 = sheet.getRow(2);
        int Statusint=0;
     
        for(int j=1;j<=rowCount;j++)
        {
        	row1 = sheet.getRow(j);
        	String cell = row1.getCell(0).getStringCellValue().trim();
        	System.out.println("cell"+cell);
        	String IRNumber;
        	try {
        		IRNumber= row1.getCell(0).getStringCellValue().trim();
        		String kk = IRRetest.call_me(IRNumber);
        		System.out.println(kk);
        		Cell cell1=null;
        		cell1= row1.createCell(2);
        		cell1.setCellValue(kk);
        		
        		
        	}
        	catch(Exception e){
        		IRNumber= "NA";
        	}
        	
        }
        	inputStream.close();
	       FileOutputStream output_file =new FileOutputStream(file); 
	       RunManger.write(output_file); 
	       output_file.close(); 
		try {
	         //Reportjson.call_me();
	        } catch (Exception e) {
	         e.printStackTrace();
	       }
	}
	public static String call_me(String IRNuM) throws Exception {
		String url = "https://onejira.verizon.com/rest/api/2/issue/"+IRNuM+"?fields=status";
		
	        URL obj = new URL(url);
	        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
	        // optional default is GET
	        con.setRequestMethod("GET");
	        //add request header
	        String loginPassword = "v113865"+ ":" + "March$2018";
	        //@SuppressWarnings("restriction")
			//String encoded = new sun.misc.BASE64Encoder().encode (loginPassword.getBytes());
	        
	       con.setRequestProperty ("Authorization", "Basic " + loginPassword);
	        
	        
	       con.setRequestProperty("Content-Type", "application/json");
	        
	        con.setUseCaches (false);
	        con.setDoInput(true);
	       con.setDoOutput(true);
	        
	        //int responseCode = con.getResponseCode();
	        System.out.println("\nSending 'GET' request to URL : " + url);
	        //System.out.println("Response Code : " + responseCode);
	        BufferedReader in = new BufferedReader(
	        new InputStreamReader(con.getInputStream()));
	        String inputLine;
	        StringBuffer response = new StringBuffer();
	        while ((inputLine = in.readLine()) != null) {
	        	response.append(inputLine);
	        }
	        in.close();
	        
	        
	        
	        //print in String
	        System.out.println(response.toString());
	        
	        //Read JSON response and print
	        JSONObject myResponse = new JSONObject(response.toString());
	        
	        System.out.println("result after Reading JSON Response");
	        //System.out.println("origin- "+myResponse.getJSONObject("name"));
	        System.out.println("IR Status is- "+myResponse.getJSONObject("fields").getJSONObject("status").getString("name"));
	        String status = myResponse.getJSONObject("fields").getJSONObject("status").getString("name");
	        
			return status;
	        
	        
	        /*JSONObject json = new JSONObject(response.toString());
	        JSONArray result = json.getJSONArray();*/
	        
	 /*       JSONObject result1 = result.getJSONObject(0);
	        JSONObject geometry = result1.getJSONObject("name");*/
	        //JSONObject locat = geometry.getJSONObject("location");
	        
	        
	         
		    }
	}
	
	


